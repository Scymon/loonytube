"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import Avatar from "@/components/Avatar";

export type Profile = { id: string; username: string | null; full_name: string | null; bio: string | null; avatar_url: string | null };

export default function ProfileEditor({ initial }: { initial: Profile }) {
  const supabase = createClient();
  const [p, setP] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function save() {
    setBusy(true); setMsg(null);
    const { error } = await supabase.from("profiles").update({
      full_name: p.full_name?.trim() || null,
      username: p.username?.trim() || null,
      bio: p.bio?.trim() || null,
      avatar_url: p.avatar_url?.trim() || null,
    }).eq("id", p.id);
    setBusy(false);
    if (error) {
      setMsg({ ok: false, text: error.code === "23505" ? "That username is already taken." : error.message });
    } else {
      setMsg({ ok: true, text: "Profile saved." });
    }
  }

  return (
    <div className="max-w-xl space-y-5">
      <div className="flex items-center gap-4">
        <Avatar name={p.full_name || p.username} src={p.avatar_url} size={72} />
        <div className="flex-1">
          <label className="lt-label">Avatar image URL</label>
          <input className="lt-input" value={p.avatar_url ?? ""} onChange={(e) => setP({ ...p, avatar_url: e.target.value })} placeholder="https://…" />
          <p className="mt-1 text-xs text-mist/70">Direct image upload — coming soon. Paste a URL for now.</p>
        </div>
      </div>

      <div>
        <label className="lt-label">Display name</label>
        <input className="lt-input" value={p.full_name ?? ""} onChange={(e) => setP({ ...p, full_name: e.target.value })} placeholder="Your channel name" />
      </div>

      <div>
        <label className="lt-label">Username</label>
        <div className="flex items-center">
          <span className="rounded-l-[10px] border border-r-0 border-edge bg-surface px-3 py-2.5 text-sm text-mist">@</span>
          <input className="lt-input rounded-l-none" value={p.username ?? ""} onChange={(e) => setP({ ...p, username: e.target.value.replace(/\s/g, "") })} placeholder="username" />
        </div>
      </div>

      <div>
        <label className="lt-label">Bio</label>
        <textarea className="lt-input min-h-[110px]" value={p.bio ?? ""} onChange={(e) => setP({ ...p, bio: e.target.value })} placeholder="Tell viewers about your channel…" />
      </div>

      {msg && <p className={`text-sm ${msg.ok ? "text-teal" : "text-loonred"}`}>{msg.text}</p>}

      <button onClick={save} disabled={busy} className="rounded-[10px] px-6 py-3 text-sm font-bold text-ink disabled:opacity-50" style={{ backgroundImage: "linear-gradient(180deg,#3ad6bd,#3e9fe6)" }}>
        {busy ? "Saving…" : "Save profile"}
      </button>
    </div>
  );
}
