import { createClient } from "@/lib/supabase/server";
import ProfileEditor, { type Profile } from "@/components/studio/ProfileEditor";

export const dynamic = "force-dynamic";

export default async function StudioProfile() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const uid = user!.id;

  const { data } = await supabase
    .from("profiles").select("id, username, full_name, bio, avatar_url").eq("id", uid).maybeSingle();

  const profile: Profile = data ?? { id: uid, username: null, full_name: null, bio: null, avatar_url: null };

  return (
    <div>
      <h1 className="text-2xl font-bold">Edit profile</h1>
      <p className="mt-1 text-sm text-mist">How your channel appears across LoonyTube.</p>
      <div className="mt-6"><ProfileEditor initial={profile} /></div>
    </div>
  );
}
