import { createClient } from "@/lib/supabase/server";
import PostsTable, { type PostRow } from "@/components/studio/PostsTable";

export const dynamic = "force-dynamic";

export default async function StudioPosts() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const uid = user!.id;

  // all of the user's posts (roots + their own continuations)
  const { data: mine } = await supabase
    .from("posts").select("id, body, parent_id, created_at").eq("owner", uid)
    .order("created_at", { ascending: false });
  const all = mine ?? [];
  const roots = all.filter((p) => !p.parent_id);
  const rootIds = roots.map((p) => p.id);

  // a root is a "thread" if the author chained their own continuation under it
  const ownChildOf = new Set(all.filter((p) => p.parent_id && rootIds.includes(p.parent_id)).map((p) => p.parent_id as string));

  // reply + like tallies (replies from anyone)
  const repC = new Map<string, number>(), likeC = new Map<string, number>();
  if (rootIds.length) {
    const [{ data: rp }, { data: lk }] = await Promise.all([
      supabase.from("posts").select("parent_id").in("parent_id", rootIds),
      supabase.from("post_likes").select("post_id").in("post_id", rootIds),
    ]);
    for (const r of rp ?? []) if (r.parent_id) repC.set(r.parent_id, (repC.get(r.parent_id) ?? 0) + 1);
    for (const l of lk ?? []) likeC.set(l.post_id, (likeC.get(l.post_id) ?? 0) + 1);
  }

  const rows: PostRow[] = roots.map((p) => ({
    id: p.id, body: p.body, isThread: ownChildOf.has(p.id),
    replies: repC.get(p.id) ?? 0, likes: likeC.get(p.id) ?? 0, created_at: p.created_at,
  }));

  return (
    <div>
      <h1 className="text-2xl font-bold">Posts &amp; threads</h1>
      <p className="mt-1 text-sm text-mist">Your Loon Posts. Multi-part threads are flagged.</p>
      <div className="mt-6"><PostsTable initial={rows} /></div>
    </div>
  );
}
