import { createClient } from "@/lib/supabase/server";
import StreamPlayer from "@/components/StreamPlayer";
import LikeButton from "@/components/LikeButton";
import Comments from "@/components/Comments";
import ProcessingWatcher from "@/components/ProcessingWatcher";

export const dynamic = "force-dynamic";

export default async function Watch({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: video } = await supabase
    .from("videos")
    .select("id, title, description, status, views, created_at, profiles(username)")
    .eq("id", id)
    .maybeSingle();

  if (!video) {
    return (
      <p className="py-16 text-center text-gray-400">
        Video not found — or still private while it processes.
      </p>
    );
  }

  if (video.status !== "ready") {
    return (
      <div className="py-16 text-center text-gray-400">
        <ProcessingWatcher videoId={id} />
        <p className="text-xl">Processing on Cloudflare…</p>
        <p className="mt-2 text-sm">This page refreshes automatically when it&apos;s ready.</p>
      </div>
    );
  }

  const profiles = (Array.isArray(video.profiles)
    ? video.profiles[0]
    : video.profiles) as { username: string | null } | undefined;

  return (
    <div className="mx-auto max-w-4xl">
      <StreamPlayer uid={id} />
      <div className="mt-4 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold">{video.title}</h1>
          <p className="mt-1 text-sm text-gray-400">
            {profiles?.username ?? "someone"} · {video.views} views
          </p>
        </div>
        <LikeButton videoId={id} />
      </div>
      {video.description && (
        <p className="mt-4 whitespace-pre-wrap rounded-lg border border-edge bg-panel p-4 text-sm text-gray-300">
          {video.description}
        </p>
      )}
      <Comments videoId={id} />
    </div>
  );
}
